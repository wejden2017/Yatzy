terraform/
├── modules/
│   ├── s3-backend/
│   │   ├── main.tf          # Création S3 et DynamoDB pour backend
│   │   ├── variables.tf     # Variables pour module s3-backend
│   │   └── outputs.tf       # Outputs du bucket et dynamo
│   └── s3-bucket/
│       ├── bucket.tf        # Création d'un bucket sécurisé
│       ├── variables.tf     # Variables pour module s3-bucket
│       └── outputs.tf       # Outputs du bucket
└── environments/
└── poc/
├── main.tf          # Appel des modules
├── variables.tf     # Variables globales
├── poc.tfvars       # Fichier de valeurs
├── data.tf          # Datas pour récupérer subnet/VPC existants
├── backend.tf       # Backend pour stocker le terraform state


ou
terraform/
├── environments/ 
│   ├── poc/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── data.tf
│   │   ├── outputs.tf
│   │   ├── poc.tfvars
├── modules/
│   ├── s3-backend/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
├── providers.tf
├── versions.tf
├── backend.tf

Structure des répertoires
project/
├── environments/
│   └── poc/
│       ├── backend.tf
│       ├── data.tf
│       ├── locals.tf
│       ├── main.tf
│       ├── monitoring.tf    (Nouveau)
│       ├── outputs.tf       (Nouveau)
│       ├── poc.tfvars
│       ├── provider.tf
│       └── variables.tf
└── modules/
├── ec2/
│   ├── locals.tf        (Nouveau)
│   ├── main.tf          (Amélioré)
│   ├── outputs.tf       (Amélioré)
│   └── variables.tf     (Amélioré)
└── s3-backend/
├── main.tf          (Amélioré)
├── outputs.tf
└── variables.tf     (Amélioré)
